#!/bin/bash

DATABASE="/home/DATABASE/users.db"

clear
echo -e "\033[01;36mLista de usuários e limite de conexões simultâneas do mesmo:"; echo ""
NUMBER=$(awk 'END{print NR}' $DATABASE)
if [ $NUMBER = "0" ]; then
  echo -e "\033[01;33mVocê não possui nenhum usuário SSH criado no momento!"
  echo ""
  echo -e "\033[01;33mCrie um usuário SSH para prosseguir com esta função!"
  echo ""
  echo -e "\033[01;36mAPERTE A TECLA ENTER PARA VOLTAR AO MENU..."
  read ENTER
  usersmanager-menu
  exit
else
  cat $DATABASE | sort | while read DB; do
    LIMIT1=$(echo $DB | cut -d " " -f1)
    LIMIT2=$(echo $DB | cut -d " " -f3)
    echo -ne "\033[01;33m"; printf '%-36s%s\n' " $LIMIT1" "$LIMIT2"
  done
fi
echo ""
echo -e "\033[01;32m0: Retornar ao menu."
echo -e "\033[01;32mR: Resetar."
echo ""
echo -ne "\033[01;36mNome do usuário para alterar o limite:\033[01;37m "; read USER
if [ -z $USER ]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um nome de usuário vazio. Tente novamente!\033[0m"
  sleep 3s
  changelimit
  exit
else
if [ "$USER" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$USER" = "R" ]; then
  changelimit
  exit
else
  awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort > /tmp/users.txt
if [[ `grep -cx "$USER" /tmp/users.txt` -ne 1 ]]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um nome de usuário inexistente. Digite um nome de\033[0m"; echo -e "\033[01;37;41musuário que seja existente na lista acima. Tente novamente!   \033[0m"
  sleep 7s
  changelimit
  exit
else
  echo -ne "\033[01;36mNovo N° de conexões simultâneas permitidas para o usuário:\033[01;37m "; read NUMBER
if echo $NUMBER | grep -q '[^0-9R]'; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um número inválido. Tente novamente!\033[0m"
  sleep 7s
  changelimit
  exit
else
if [ -z $NUMBER ]; then
  echo ""
  echo -e "\033[1;37;41mVocê digitou um número vazio. Tente novamente!\033[0m"
  sleep 3s
  changelimit
  exit
else
if [ "$NUMBER" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$NUMBER" = "R" ]; then
  changelimit
  exit
else
  clear
  cat $DATABASE | grep -w "$USER" | cut -d " " -f2 > password.txt
  cat $DATABASE | grep -wv "$USER" > limit.txt
  mv limit.txt $DATABASE
  echo "$USER $(cat password.txt; rm password.txt) $NUMBER" >> $DATABASE
  echo -e "\033[01;36mLista de usuários e limite de conexões do mesmo:"; echo ""
  cat $DATABASE | sort | while read DB; do
    LIMIT1=$(echo $DB | cut -d " " -f1)
    LIMIT2=$(echo $DB | cut -d " " -f3)
    echo -ne "\033[01;33m"; printf '%-36s%s\n' " $LIMIT1" "$LIMIT2"
  done
  echo ""
  echo -e "\033[01;37m Limite de conexões simultâneas do usuário alterado com sucesso!"
  echo ""
  echo -e "\033[01;32m Verifique as informações abaixo:"
  echo ""
  echo -e "\033[01;37m Nome do usuário: $USER"
  echo -e "\033[01;37m N° de conexões simultâneas permitidas alterado para: $NUMBER"
fi
fi
fi
fi
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAPERTE A TECLA ENTER..."
read ENTER
changelimit
exit