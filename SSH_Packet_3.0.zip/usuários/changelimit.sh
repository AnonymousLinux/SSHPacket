#!/bin/bash

DATABASE="/home/DATABASE/users.db"

clear
echo -e "\033[01;36mLista de usuários e limite de conexões simultâneas do mesmo:"; echo ""
NUMBER=$(awk 'END{print NR}' $DATABASE)
if [ $NUMBER = "0" ]; then
  echo -e "\033[01;33mVocê não possui nenhum usuário SSH criado no momento!"
  echo ""
  echo -e "\033[01;37mCrie um usuário SSH para prosseguir com esta função!"
  echo ""
  echo -e "\033[01;36mAperte a tecla ENTER para voltar ao menu..."
  read ENTER
  usersmanager-menu
  exit
else
  cat $DATABASE | sort | while read DB; do
    USERS=$(echo $DB | cut -d " " -f1)
    LIMIT=$(echo $DB | cut -d " " -f2)
    echo -ne "\033[01;32m"; printf '%-36s%s\n' " $USERS" "$LIMIT"
  done
fi
echo ""
echo -e "\033[01;37m0: Retornar ao menu."
echo -e "\033[01;37mR: Resetar."
echo ""
echo -ne "\033[01;36mNome do usuário para alterar o limite:\033[01;37m "; read USER
if [ -z $USER ]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome de usuário vazio. Tente novamente!\033[0m"
  sleep 3s
  changelimit
  exit
else
if [ "$USER" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$USER" = "R" ]; then
  changelimit
  exit
else
  awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort > /tmp/users.txt
if [[ `grep -cx "$USER" /tmp/users.txt` -ne 1 ]]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome de usuário inexistente. Digite um nome de\033[0m"; echo -e "\033[01;37;44musuário que seja existente na lista acima. Tente novamente!   \033[0m"
  sleep 7s
  changelimit
  exit
else
  echo -ne "\033[01;36mNovo N° de conexões simultâneas permitidas para o usuário:\033[01;37m "; read NUMBER
if echo $NUMBER | grep -q '[^0-9R]'; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um número inválido. Tente novamente!\033[0m"
  sleep 7s
  changelimit
  exit
else
if [ -z $NUMBER ]; then
  echo ""
  echo -e "\033[1;37;44mVocê digitou um número vazio. Tente novamente!\033[0m"
  sleep 3s
  changelimit
  exit
else
if [ "$NUMBER" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$NUMBER" = "R" ]; then
  changelimit
  exit
else
  clear
  cat $DATABASE | grep -wv "$USER" > limit.txt
  mv limit.txt $DATABASE
  echo "$USER $NUMBER" >> $DATABASE
  echo -e "\033[01;36mLista de usuários e limite de conexões do mesmo:"; echo ""
  cat $DATABASE | sort | while read DB; do
    USERS=$(echo $DB | cut -d " " -f1)
    LIMIT=$(echo $DB | cut -d " " -f2)
    echo -ne "\033[01;32m"; printf '%-36s%s\n' " $USERS" "$LIMIT"
  done
  echo ""
  echo -e "\033[01;37mLimite de conexões simultâneas do usuário alterado com sucesso!"
  echo -e "\033[01;37mNome do usuário: $USER"
  echo -e "\033[01;37mN° de conexões simultâneas permitidas alterado para: $NUMBER"
fi
fi
fi
fi
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAperte a tecla ENTER..."
read ENTER
changelimit
exit