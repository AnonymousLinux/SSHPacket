#!/bin/bash

checkdatabase

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
NUMBER=$(ps -x | grep -c "sleep")
if [ $NUMBER = "2" ]; then
  echo -e "\033[01;37m  Estado:\033[01;32m ATIVO :)"
else
  echo -e "\033[01;37m  Estado:\033[01;31m DESATIVADO :("
fi
echo ""
echo -e "\033[01;36m  [\033[01;37m1\033[01;36m]\033[01;36m Ativar limitador de conexões SSH simultâneas."
echo -e "\033[01;36m  [\033[01;37m2\033[01;36m]\033[01;36m Desativar limitador de conexões SSH simultâneas."
echo -e "\033[01;36m  [\033[01;37m3\033[01;36m]\033[01;36m Verificar caixa de mensagens."
echo -e "\033[01;36m  [\033[01;37m4\033[01;36m]\033[01;36m Voltar."
echo ""
echo -ne "\033[01;36m  [\033[01;37m1-4\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  1) NUMBER=$(ps -x | grep -c "sleep")
      if [ $NUMBER = "2" ]; then
        echo ""
        echo -e "\033[01;37;44mLimitador de conexões SSH simultâneas já está ATIVO!\033[0m"
        sleep 3s
        limiter-menu
        exit
      else
        echo ""
        echo -e "\033[01;37mAguarde..."
        limiter-start&> /dev/null &
        sleep 3s
        clear
        limiter-menu
        exit
      fi;;
  2) NUMBER=$(ps -x | grep -c "sleep")
      if [ $NUMBER = "2" ]; then
        echo ""
        echo -e "\033[01;37mAguarde..."
        pkill -f limiter-start
        sleep 3s
        clear
        limiter-menu
        exit
      else
        echo ""
        echo -e "\033[01;37;44mLimitador de conexões SSH simultâneas não está ATIVO!\033[0m"
        sleep 3s
        limiter-menu
        exit
      fi;;
  3) limiter-messages;;
  4) usersmanager-menu;;
  *) limiter-menu;;
esac
  
  
