#!/bin/bash

checkdatabase

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;36m   [\033[01;37m1\033[01;36m]\033[01;36m Alterar a data de validade de um usuário SSH."
echo -e "\033[01;36m   [\033[01;37m2\033[01;36m]\033[01;36m Alterar a mensagem do servidor (BANNER)."
echo -e "\033[01;36m   [\033[01;37m3\033[01;36m]\033[01;36m Alterar a senha de um usuário SSH."
echo -e "\033[01;36m   [\033[01;37m4\033[01;36m]\033[01;36m Alterar o N° de conexões permitidas de um usuário SSH."
echo -e "\033[01;36m   [\033[01;37m5\033[01;36m]\033[01;36m Criar um usuário SSH sem acesso ao terminal."
echo -e "\033[01;36m   [\033[01;37m6\033[01;36m]\033[01;36m Desconectador de conexões de usuários SSH."
echo -e "\033[01;36m   [\033[01;37m7\033[01;36m]\033[01;36m Gerenciamento de backups de usuários SSH."
echo -e "\033[01;36m   [\033[01;37m8\033[01;36m]\033[01;36m Limitador de conexões SSH simultâneas."
echo -e "\033[01;36m   [\033[01;37m9\033[01;36m]\033[01;36m Remover todos os usuários SSH expirados."
echo -e "\033[01;36m  [\033[01;37m10\033[01;36m]\033[01;36m Remover um usuário SSH."
echo -e "\033[01;36m  [\033[01;37m11\033[01;36m]\033[01;36m Verificar o N° de conexões simultâneas de cada usuário SSH."
echo -e "\033[01;36m  [\033[01;37m12\033[01;36m]\033[01;36m Verificar todos os usuários SSH criados."
echo -e "\033[01;36m  [\033[01;37m13\033[01;36m]\033[01;36m Voltar."
echo ""
echo -ne "\033[01;36m  [\033[01;37m1-13\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  1) changedate;;
  2) bannerssh;;
  3) changepassword;;
  4) changelimit;;
  5) createuser;;
  6) userdisconnect;;  
  7) backupsmanager-menu;;
  8) limiter-menu;;
  9) removeexpired;;
10) removeuser;;
11) monitoring;;
12) checkusers;;
13) sshpacket;;
  *) usersmanager-menu;;
esac
  
  
  
  