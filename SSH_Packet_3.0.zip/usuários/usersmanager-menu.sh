#!/bin/bash

checkdatabase

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""

NUMBER1=$(awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | wc -l)

for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
  EXPIRE=$(chage -l $USERS | grep -E "Account expires" | cut -d " " -f3-)
  if [[ $EXPIRE = "never" ]]; then
    echo "" > /dev/null
  else
    DATEBR=$(date -d "$EXPIRE" '+%Y%m%d')
    TODAY=$(date -d today '+%Y%m%d')
  if [ $TODAY -ge $DATEBR ]; then
    NUMBER2=$(echo $USERS | wc -l)
  else
    echo "" > /dev/null
  fi
  fi
done

for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
  NUMBER=$(ps -u $USERS | grep sshd | wc -l)
    if [ "$NUMBER" -gt "0" ]; then
      NUMBER3=$(echo $USERS | wc -l)
    else
      echo "" > /dev/null
    fi
done

NUMBER4=$(ls /home/DATABASE/Backups | wc -l)

if [ $NUMBER1 = "0" ]; then
  echo -e "\033[01;36m Usuários SSH:\033[01;37m 0"
else
  echo -e "\033[01;36m Usuários SSH:\033[01;37m $NUMBER1"
fi
if [ -z $NUMBER2 ]; then
  echo -e "\033[01;36m Expirados:\033[01;37m 0"
else
  echo -e "\033[01;36m Expirados:\033[01;37m $NUMBER2"
fi
if [ -z $NUMBER3 ]; then
  echo -e "\033[01;36m Online:\033[01;37m 0"
else
  echo -e "\033[01;36m Online:\033[01;37m $NUMBER3"
fi
if [ $NUMBER4 = "0" ]; then
  echo -e "\033[01;36m Backups:\033[01;37m 0"
else
  echo -e "\033[01;36m Backups:\033[01;37m $NUMBER4"
fi

echo""
echo -e "\033[01;36m  [\033[01;37m01\033[01;36m]\033[01;36m Alterar a data de validade de um usuário SSH."
echo -e "\033[01;36m  [\033[01;37m02\033[01;36m]\033[01;36m Alterar a mensagem do servidor (BANNER)."
echo -e "\033[01;36m  [\033[01;37m03\033[01;36m]\033[01;36m Alterar a senha de um usuário SSH."
echo -e "\033[01;36m  [\033[01;37m04\033[01;36m]\033[01;36m Alterar o N° de conexões permitidas de um usuário SSH."
echo -e "\033[01;36m  [\033[01;37m05\033[01;36m]\033[01;36m Criar um usuário SSH sem acesso ao terminal."
echo -e "\033[01;36m  [\033[01;37m06\033[01;36m]\033[01;36m Desconectador de conexões de usuários SSH."
echo -e "\033[01;36m  [\033[01;37m07\033[01;36m]\033[01;36m Gerenciamento de backups de usuários SSH."
echo -e "\033[01;36m  [\033[01;37m08\033[01;36m]\033[01;36m Limitador de conexões SSH simultâneas."
echo -e "\033[01;36m  [\033[01;37m09\033[01;36m]\033[01;36m Removedor de usuários SSH expirados."
echo -e "\033[01;36m  [\033[01;37m10\033[01;36m]\033[01;36m Remover um usuário SSH."
echo -e "\033[01;36m  [\033[01;37m11\033[01;36m]\033[01;36m Verificar o N° de conexões simultâneas de cada usuário SSH."
echo -e "\033[01;36m  [\033[01;37m12\033[01;36m]\033[01;36m Voltar."
echo ""
echo -ne "\033[01;36m  [\033[01;37m01-12\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  01) changedate;;
  02) bannerssh;;
  03) changepassword;;
  04) changelimit;;
  05) createuser;;
  06) userdisconnect;;  
  07) backupsmanager-menu;;
  08) limiter-menu;;
  09) removeexpired;;
  10) removeuser;;
  11) monitoring;;
  12) sshpacket;;
    *) usersmanager-menu;;
esac