#!/bin/bash

clear
echo -e "\033[01;36mLista de usuários e data de expiração do mesmo:"; echo ""
NUMBER=$(awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort | wc -l)
if [ $NUMBER = "0" ]; then
  echo -e "\033[01;33mVocê não possui nenhum usuário SSH criado no momento!"
  echo ""
  echo -e "\033[01;33mCrie um usuário SSH para prosseguir com esta função!"
  echo ""
  echo -e "\033[01;36mAPERTE A TECLA ENTER PARA VOLTAR AO MENU..."
  read ENTER
  usersmanager-menu
  exit
else
  for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
    EXPIRE=$(chage -l $USERS | grep -E "Account expires" | cut -d " " -f3-)
    if [[ $EXPIRE = "never" ]]; then
      echo -ne "\033[01;33m$(printf '%-36s%s\n' " $USERS" "Nunca")"; echo -e "\033[01;32m      (ATIVO)"
    else
      DATEBR=$(date -d "$EXPIRE" '+%Y%m%d')
      TODAY=$(date -d today '+%Y%m%d')
    if [ $TODAY -ge $DATEBR ]; then
      DATE=$(date -d "$EXPIRE" '+%d/%m/%Y')
      echo -ne "\033[01;33m$(printf '%-36s%s\n' " $USERS" "$DATE")"; echo -e "\033[01;31m (EXPIRADO)"
    else
      DATE=$(date -d "$EXPIRE" '+%d/%m/%Y')
      echo -ne "\033[01;33m$(printf '%-36s%s\n' " $USERS" "$DATE")"; echo -e "\033[01;32m (ATIVO)"
    fi
    fi
  done
fi
echo ""
echo -e "\033[01;32m0: Retornar ao menu."
echo -e "\033[01;32mR: Resetar."
echo ""
echo -ne "\033[01;36mNome do usuário para alterar a data de validade:\033[01;37m "; read USER
if [ -z $USER ]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um nome de usuário vazio. Tente novamente!\033[0m"
  sleep 3s
  changedate
  exit
else
if [ "$USER" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$USER" = "R" ]; then
  changedate
  exit
else
  awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort > /tmp/users.txt
if [[ `grep -cx "$USER" /tmp/users.txt` -ne 1 ]]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um nome de usuário inexistente. Digite um nome de\033[0m"; echo -e "\033[01;37;41musuário que seja existente na lista acima. Tente novamente!   \033[0m"
  sleep 7s
  changedate
  exit
else
  echo -ne "\033[01;36mNova data de expiração (DIA/MÊS/ANO) para o usuário:\033[01;37m "; read NEWDATE
if [ -z $NEWDATE ]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou uma data vazia. Tente novamente!\033[0m"
  sleep 3s
  changedate
  exit
else
if echo "$NEWDATE" | grep -q '[^0-9/R]'; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou uma data inválida. Tente novamente!\033[0m"
  sleep 3s
  changedate
  exit
else
if [ "$NEWDATE" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$NEWDATE" = "R" ]; then
  changedate
  exit
else
  TODAY=$(date -d today '+%Y%m%d')
  TEMP=$(date -d "$NEWDATE" '+%Y%m%d')
if [[ $TODAY -ge $TEMP ]]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou uma data inválida. Digite uma data futura no form\033[0m"; echo -e "\033[01;37;41mato: DIA/MÊS/ANO, por exemplo: 01/01/2019. Tente novamente!   \033[0m"
  sleep 7s
  changedate
  exit
else
  DATE1=$(echo "$NEWDATE" | cut -d "/" -f3)
  DATE2=$(echo "$NEWDATE" | cut -d "/" -f2)
  DATE3=$(echo "$NEWDATE" | cut -d "/" -f1)
  chage -E $DATE1/$DATE2/$DATE3 $USER
  clear
  echo -e "\033[01;36mLista de usuários e data de expiração do mesmo:"; echo ""
  for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
    EXPIRE=$(chage -l $USERS | grep -E "Account expires" | cut -d " " -f3-)
    if [[ $EXPIRE = "never" ]]; then
      echo -ne "\033[01;33m$(printf '%-36s%s\n' " $USERS" "Nunca")"; echo -e "\033[01;32m      (ATIVO)"
    else
      DATEBR=$(date -d "$EXPIRE" '+%Y%m%d')
      TODAY=$(date -d today '+%Y%m%d')
    if [ $TODAY -ge $DATEBR ]; then
      DATE=$(date -d "$EXPIRE" '+%d/%m/%Y')
      echo -ne "\033[01;33m$(printf '%-36s%s\n' " $USERS" "$DATE")"; echo -e "\033[01;31m (EXPIRADO)"
    else
      DATE=$(date -d "$EXPIRE" '+%d/%m/%Y')
      echo -ne "\033[01;33m$(printf '%-36s%s\n' " $USERS" "$DATE")"; echo -e "\033[01;32m (ATIVO)"
    fi
    fi
  done
  echo ""
  echo -e "\033[01;32m Data de expiração do usuário alterada com sucesso!"
  echo ""
  echo -e "\033[01;32m Verifique as informações abaixo:"
  echo ""
  echo -e "\033[01;32m Nome do usuário: $USER"
  echo -e "\033[01;32m Data de expiração do usuário alterada para: $NEWDATE"
fi
fi
fi
fi
fi
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAPERTE A TECLA ENTER..."
read ENTER
changedate
exit