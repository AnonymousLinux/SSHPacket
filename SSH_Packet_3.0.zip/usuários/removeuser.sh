#!/bin/bash

DATABASE="/home/DATABASE/users.db"

clear
echo -e "\033[01;36mLista de usuários criados:\033[01;32m 0: Retornar ao menu."
echo ""
NUMBER=$(awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort | wc -l)
if [ $NUMBER = "0" ]; then
  echo -e "\033[01;33mVocê não possui nenhum usuário SSH criado no momento!"
  echo ""
  echo -e "\033[01;33mCrie um usuário SSH para prosseguir com esta função!"
  echo ""
  echo -e "\033[01;36mAPERTE A TECLA ENTER PARA VOLTAR AO MENU..."
  read ENTER
  usersmanager-menu
  exit
else
  for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
    echo -ne "\033[01;33m"; echo $USERS
  done
fi
echo ""
echo -ne "\033[01;36mNome do usuário para remover:\033[01;37m "; read USER
if [ -z $USER ]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um nome de usuário vazio. Tente novamente!\033[0m"
  sleep 3s
  removeuser
  exit
else
if [ "$USER" = "0" ]; then
  usersmanager-menu
  exit
else
  awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort > /tmp/users.txt
if [[ `grep -cx "$USER" /tmp/users.txt` -ne 1 ]]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um nome de usuário inexistente. Digite um nome de\033[0m"; echo -e "\033[01;37;41musuário que seja existente na lista acima. Tente novamente!   \033[0m"
  sleep 7s
  removeuser
  exit
else
  clear
  pkill -f $USER
  userdel -f $USER 1> /dev/null 2> /dev/null
  cat $DATABASE | grep -wv "$USER" > remove.txt
  mv remove.txt $DATABASE
  echo -e "\033[01;36mLista de usuários criados:"; echo ""
  NUMBER=$(awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort | wc -l)
  if [ $NUMBER = "0" ]; then
    echo -e "\033[01;33mVocê não possui nenhum usuário SSH criado no momento!"
  else
    for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
      echo -ne "\033[01;33m"; echo $USERS
    done
  fi
  echo ""
  echo -e "\033[01;32m Usuário removido com sucesso!"
  echo -e "\033[01;32m Nome do usuário: $USER"
fi
fi
fi
echo ""
echo -ne "\033[01;36mAPERTE A TECLA ENTER..."
read ENTER
removeuser
exit