#!/bin/bash

DATABASE="/home/DATABASE/users.db"

clear
echo -e "\033[01;36mLista de usuários criados: \033[01;37m0: Retornar ao menu.
                           R: Resetar."
echo ""
NUMBER=$(awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort | wc -l)
if [ $NUMBER = "0" ]; then
  echo -e "\033[01;33mVocê não possui nenhum usuário SSH criado no momento!"
else
  for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
    echo -ne "\033[01;32m"; echo $USERS
  done
fi
echo ""
echo -ne "\033[01;36mNome de usuário:\033[01;37m "; read USER
if [ -z $USER ]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome de usuário vazio. Tente novamente!\033[0m"
  sleep 3s
  createuser
  exit
else
if [ "$USER" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$USER" = "R" ]; then
  createuser
  exit
else
if echo $USER | grep -q '[^a-z A-Z 0-9 ._-]'; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome de usuário inválido. Use apenas letras, números\033[0m"; echo -e "\033[01;37;44mpontos e traços. Não use espaços, acentos ou caracteres especiais. T\033[0m"; echo -e "\033[01;37;44mente novamente!                                                     \033[0m"
  sleep 10s
  createuser
  exit
else
  awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort > /tmp/users.txt
if grep -xq "$USER" /tmp/users.txt; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome de usuário já existente. Digite um nome de\033[0m"; echo -e "\033[01;37;44musuário que não seja existente na lista acima. Tente novamente!\033[0m"
  sleep 7s
  createuser
  exit
else
  CHARACTERS=$(echo $USER | wc -c)
if [ $CHARACTERS -gt 33 ]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome de usuário muito grande. Use no máximo 3\033[0m"; echo -e "\033[01;37;44m2 caracteres para o usuário. Tente novamente!                \033[0m"
  sleep 7s
  createuser
  exit
else
  echo -ne "\033[01;36mSenha:\033[01;37m "; read PASSWORD
if [ -z $PASSWORD ]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou uma senha vazia. Tente novamente!\033[0m"
  sleep 3s
  createuser
  exit
else
if [ "$PASSWORD" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$PASSWORD" = "R" ]; then
  createuser
  exit
else
  echo -ne "\033[01;36mN° de dias para expirar:\033[01;37m "; read DAYS
if echo $DAYS | grep -q '[^0-9R]'; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um número de dias inválido. Tente novamente!\033[0m"
  sleep 3s
  createuser
  exit
else
if [ -z $DAYS ]; then
  echo ""
  echo -e "\033[1;37;44mVocê digitou um número vazio. Tente novamente!\033[0m"
  sleep 3s
  createuser
  exit
else
if [ "$DAYS" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$DAYS" = "R" ]; then
  createuser
  exit
else
  echo -ne "\033[01;36mN° de conexões simultâneas permitidas:\033[01;37m "; read CONNECTIONS
if echo $CONNECTIONS | grep -q '[^0-9R]'; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um número inválido. Tente novamente!\033[0m"
  sleep 7s
  createuser
  exit
else
if [ -z $CONNECTIONS ]; then
  echo ""
  echo -e "\033[1;37;44mVocê digitou um número vazio. Tente novamente!\033[0m"
  sleep 3s
  createuser
  exit
else
if [ "$CONNECTIONS" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$CONNECTIONS" = "R" ]; then
  createuser
  exit
else
  echo ""
  VALIDITY1=$(date "+%Y-%m-%d" -d "+ $DAYS days")
  VALIDITY2=$(date "+%d/%m/%Y" -d "+ $DAYS days")
  useradd -e $VALIDITY1 -M -s /bin/false $USER
  (echo $PASSWORD; echo $PASSWORD) | passwd $USER 1> /dev/null 2> /dev/null
  echo "$USER $CONNECTIONS" >> $DATABASE
  clear
  echo -e "\033[01;36mLista de usuários criados:"; echo ""
  for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
    echo -ne "\033[01;32m"; echo $USERS
  done
  echo ""
  echo -e "\033[01;37mUsuário criado com sucesso!"
  echo -e "\033[01;37mNome do usuário: $USER"
  echo -e "\033[01;37mData de validade: $VALIDITY2 às 00:00:00"
  echo -e "\033[01;37mN° de conexões simultâneas permitidas: $CONNECTIONS"
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAperte a tecla ENTER..."
read ENTER
createuser
exit