#!/bin/bash

FILE="/home/DATABASE/bannerssh.txt"

clear
echo -e "\033[01;36mMensagem atual: \033[01;37m0: Retornar ao menu."
echo ""
NUMBER=$(cat $FILE | wc -l)
if [ $NUMBER = "0" ]; then
  echo -e "\033[01;33mVocê não possui nenhuma mensagem no momento!"
else
  echo -ne "\033[01;32m"; cat $FILE
fi
echo ""
echo -e "\033[01;36mDigite uma mensagem:\033[01;37m"
echo ""
read BANNER
if [ "$BANNER" = "0" ]; then
  usersmanager-menu
  exit
else
  echo "$BANNER" > $FILE
  service ssh reload 1> /dev/null 2> /dev/null
  clear
  echo -e "\033[01;36mMensagem atual:"; echo ""
  NUMBER=$(cat $FILE | wc -l)
  if [ $NUMBER = "0" ]; then
    echo -e "\033[01;33mVocê não possui nenhuma mensagem no momento!"
  else
    echo -ne "\033[01;32m"; cat $FILE
  fi
  echo ""
  echo -e "\033[01;37mMensagem alterada com sucesso!"
fi
echo ""
echo -ne "\033[01;36mAperte a tecla ENTER..."
read ENTER
bannerssh
exit
  




