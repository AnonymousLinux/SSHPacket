#!/bin/bash

function CTRL() 
{
usersmanager-menu
exit
}
trap CTRL SIGINT

DATABASE="/home/DATABASE/users.db"

while true; do
  clear
  echo ""
  echo -ne " \033[01;37;44m"; printf '%38s%-28s\n' "Monitoring"; echo -ne "\033[0m"
  echo -ne " \033[01;37;44m"; printf '%-52s%s\n' " Usuário" "Conexão/Limite "; echo -e "\033[0m"
  cat $DATABASE | sort | while read DB; do
    USERS=$(echo $DB | cut -d " " -f1)
    CONNECTION=$(ps -u $USERS | grep sshd | wc -l)
    LIMIT=$(echo $DB | cut -d " " -f2)
    echo -ne " \033[01;37m"; printf '%-57s%s\n' " $USERS" "$CONNECTION/$LIMIT "
  done
  echo ""
  echo -e "\033[01;37m Aperte Ctrl+c para voltar ao menu..."
  sleep 10s
done

    

  
  