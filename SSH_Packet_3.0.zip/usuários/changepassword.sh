#!/bin/bash

DATABASE="/home/DATABASE/users.db"

clear
echo -e "\033[01;36mLista de usuários e senha de acesso dos mesmos:" 
echo ""
NUMBER=$(awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort | wc -l)
if [ $NUMBER = "0" ]; then
  echo -e "\033[01;33mVocê não possui nenhum usuário SSH criado no momento!"
  echo ""
  echo -e "\033[01;33mCrie um usuário SSH para prosseguir com esta função!"
  echo ""
  echo -e "\033[01;36mAPERTE A TECLA ENTER PARA VOLTAR AO MENU..."
  read ENTER
  usersmanager-menu
  exit
else
  cat $DATABASE | sort | while read DB; do
    PASSWORD1=$(echo $DB | cut -d " " -f1)
    PASSWORD2=$(echo $DB | cut -d " " -f2)
    echo -ne "\033[01;33m"; printf '%-36s%s\n' " $PASSWORD1" "$PASSWORD2"
  done
fi
echo ""
echo -e "\033[01;32m0: Retornar ao menu."
echo -e "\033[01;32mR: Resetar."
echo ""
echo -ne "\033[01;36mNome do usuário para alterar a senha:\033[01;37m "; read USER
if [ -z $USER ]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um nome de usuário vazio. Tente novamente!\033[0m"
  sleep 3s
  changepassword
  exit
else
if [ "$USER" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$USER" = "R" ]; then
  changepassword
  exit
else
  awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort > /tmp/users.txt
if [[ `grep -cx "$USER" /tmp/users.txt` -ne 1 ]]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um nome de usuário inexistente. Digite um nome de\033[0m"; echo -e "\033[01;37;41musuário que seja existente na lista acima. Tente novamente!   \033[0m"
  sleep 7s
  changepassword
  exit
else
  echo -ne "\033[01;36mDigite uma nova senha para o usuário:\033[01;37m "; read PASSWORD
if [ -z $PASSWORD ]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou uma senha vazia. Tente novamente!\033[0m"
  sleep 3s
  changepassword
  exit
else
if [ "$PASSWORD" = "0" ]; then
  usersmanager-menu
  exit
else
if [ "$PASSWORD" = "R" ]; then
  changepassword
  exit
else
  cat $DATABASE | grep -w "$USER" | cut -d " " -f3 > limit.txt
  cat $DATABASE | grep -wv "$USER" > password.txt
  mv password.txt $DATABASE
  echo "$USER $PASSWORD $(cat limit.txt; rm limit.txt)" >> $DATABASE
  pkill -f $USER 1> /dev/null 2> /dev/null
  (echo $PASSWORD; echo $PASSWORD) | passwd $USER 1> /dev/null 2> /dev/null
  clear
  echo -e "\033[01;36mLista de usuários criados e senha de acesso dos mesmos:"; echo ""
  cat $DATABASE | sort | while read DB; do
    PASSWORD1=$(echo $DB | cut -d " " -f1)
    PASSWORD2=$(echo $DB | cut -d " " -f2)
    echo -ne "\033[01;33m"; printf '%-36s%s\n' " $PASSWORD1" "$PASSWORD2"
  done
  echo ""
  echo -e "\033[01;32m Senha do usuário alterada com sucesso!"
  echo ""
  echo -e "\033[01;32m Verifique as informações abaixo:"
  echo ""
  echo -e "\033[01;32m Nome do usuário: $USER"
  echo -e "\033[01;32m Senha do usuário alterada para: $PASSWORD"
fi
fi
fi
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAPERTE A TECLA ENTER..."
read ENTER
changepassword
exit
