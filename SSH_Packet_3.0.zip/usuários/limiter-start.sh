#!/bin/bash

DATABASE="/home/DATABASE/users.db"

while true; do
  clear
  echo ""
  echo -ne " \033[01;37;44m"; printf '%38s%-28s\n' "Monitoring"; echo -ne "\033[0m"
  echo -ne " \033[01;37;44m"; printf '%-52s%s\n' " Usuário" "Conexão/Limite "; echo -e "\033[0m"
  cat $DATABASE | sort | while read DB; do
    USERS=$(echo $DB | cut -d " " -f1)
    CONNECTION=$(ps -u $USERS | grep sshd | wc -l)
    LIMIT=$(echo $DB | cut -d " " -f2)
    echo -ne " \033[01;37m"; printf '%-57s%s\n' " $USERS" "$CONNECTION/$LIMIT "
    if [ "$CONNECTION" -gt "$LIMIT" ]; then
      while read DISCONNECT; do
        pkill -f $USERS
        echo -e "Nome do usuário: $USERS\nN° de conexões simultâneas permitidas: $LIMIT\nQuantidade identificada: $CONNECTION\nData: $(date "+%d/%m/%Y às %H:%M:%S")\n" >> /home/DATABASE/messages.txt
        exit
      done 
    fi
  done
  sleep 5s
done