#!/bin/bash

checkdatabase

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;36m  [\033[01;37m1\033[01;36m]\033[01;36m Criar um backup."
echo -e "\033[01;36m  [\033[01;37m2\033[01;36m]\033[01;36m Importar um backup."
echo -e "\033[01;36m  [\033[01;37m3\033[01;36m]\033[01;36m Remover um backup."
echo -e "\033[01;36m  [\033[01;37m4\033[01;36m]\033[01;36m Voltar."
echo ""
echo -ne "\033[01;36m  [\033[01;37m1-4\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  1) backupsmanager-export;;
  2) backupsmanager-import;;
  3) backupsmanager-remove;;
  4) usersmanager-menu;;
  *) backupsmanager-menu;;
esac