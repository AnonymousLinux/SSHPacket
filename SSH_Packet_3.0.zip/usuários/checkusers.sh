#!/bin/bash

clear
echo -e "\033[01;36mLista de usuários criados:"; echo ""
NUMBER=$(awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort | wc -l)
if [ $NUMBER = "0" ]; then
  echo -e "\033[01;33mVocê não possui nenhum usuário SSH criado no momento!"
else
  for USERS in `awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort`; do
    echo -ne "\033[01;32m"; echo $USERS
  done
fi
echo ""
NUMBER=$(awk  -F : '$3 >= 500 {print  $1}'  /etc/passwd | grep -v "nobody" | sort | wc -l)
echo -e "\033[01;37mN° total de usuários criados: $NUMBER"
echo ""
echo -e "\033[01;36mAperte a tecla ENTER para voltar ao menu..."
read ENTER
usersmanager-menu
exit