#!/bin/bash

DOMAINS="/etc/squid/domains.txt"

if [ ! -f "$DOMAINS" ]; then
  touch $DOMAINS
  domainsmanager-remove
  exit
else
  clear
  echo -e "\033[01;36mLista de domínios atuais: \033[01;37m0: Retornar ao menu."
  echo ""
  NUMBER=$(awk 'END{print NR}' $DOMAINS)
  if [ $NUMBER = "0" ]; then
    echo -e "\033[01;33mVocê não possui nenhum domínio adicionando no momento!"
    echo ""
    echo -e "\033[01;37mÉ necessário adicionar um domínio para prosseguir com esta função!"
    echo ""
    echo -e "\033[01;36mAperte a tecla ENTER para voltar ao menu..."
    read ENTER
    domainsmanager-menu
    exit
  else
    echo -ne "\033[01;32m"; cat $DOMAINS | sort; echo ""
  fi
  echo -ne "\033[01;36mDigite o domínio que deseja remover da lista:\033[01;37m "; read DOMAIN
if [ -z $DOMAIN ]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um domínio vazio. Tente novamente!\033[0m"
  sleep 3s
  domainsmanager-remove
  exit
else
if [ "$DOMAIN" = "0" ]; then
  domainsmanager-menu
  exit
else
if [[ `grep -cx "$DOMAIN" $DOMAINS` -ne 1 ]]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um domínio inexistente. Digite um domínio que seja\033[0m"; echo -e "\033[01;37;44mexistente na lista acima. Tente novamente!                      \033[0m"
  sleep 7s
  domainsmanager-remove
  exit
else
  grep -xv "$DOMAIN" $DOMAINS > delete.txt
  mv delete.txt $DOMAINS
  if [ ! -f "/etc/init.d/squid" ]; then
    service squid reload 1> /dev/null 2> /dev/null
  else
    /etc/init.d/squid reload 1> /dev/null 2> /dev/null
  fi
  clear
  echo -e "\033[01;36mLista de domínios atuais:"; echo ""
  NUMBER=$(awk 'END{print NR}' $DOMAINS)
  if [ $NUMBER = "0" ]; then
    echo -e "\033[01;33mVocê não possui nenhum domínio adicionando no momento!"; echo ""
  else
    echo -ne "\033[01;32m"; cat $DOMAINS | sort; echo ""
  fi
  echo -e "\033[01;37mDomínio $DOMAIN removido com sucesso!"
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAperte a tecla ENTER..."
read ENTER
domainsmanager-remove
exit