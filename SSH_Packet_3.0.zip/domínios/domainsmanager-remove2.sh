#!/bin/bash

DOMAINS="/etc/squid3/domains.txt"

if [ ! -f "$DOMAINS" ]; then
  touch $DOMAINS
  domainsmanager-remove
  exit
else
  clear
  echo -e "\033[01;36mLista de domínios atuais:\033[01;32m 0: Retornar ao menu."
  echo ""
  NUMBER=$(awk 'END{print NR}' $DOMAINS)
  if [ $NUMBER = "0" ]; then
    echo -e "\033[01;33mVocê não possui nenhum domínio adicionando no momento!"
    echo ""
    echo -e "\033[01;33mÉ necessário adicionar um domínio para prosseguir com esta função!"
    echo ""
    echo -e "\033[01;36mAPERTE A TECLA ENTER PARA VOLTAR AO MENU..."
    read ENTER
    domainsmanager-menu
    exit
  else
    echo -ne "\033[01;33m"; cat $DOMAINS | sort; echo ""
  fi
  echo -ne "\033[01;36mDigite o domínio que deseja remover da lista:\033[01;37m "; read DOMAIN
if [ -z $DOMAIN ]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um domínio vazio. Tente novamente!\033[0m"
  sleep 3s
  domainsmanager-remove
  exit
else
if [ "$DOMAIN" = "0" ]; then
  domainsmanager-menu
  exit
else
if [[ `grep -cx "$DOMAIN" $DOMAINS` -ne 1 ]]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um domínio inexistente. Digite um domínio que seja\033[0m"; echo -e "\033[01;37;41mexistente na lista acima. Tente novamente!                      \033[0m"
  sleep 7s
  domainsmanager-remove
  exit
else
  grep -xv "$DOMAIN" $DOMAINS > delete.txt
  mv delete.txt $DOMAINS
  if [ ! -f "/etc/init.d/squid3" ]; then
    service squid reload3 1> /dev/null 2> /dev/null
  else
    /etc/init.d/squid reload3 1> /dev/null 2> /dev/null
  fi
  clear
  echo -e "\033[01;36mLista de domínios atuais:"; echo ""
  NUMBER=$(awk 'END{print NR}' $DOMAINS)
  if [ $NUMBER = "0" ]; then
    echo -e "\033[01;33mVocê não possui nenhum domínio adicionando no momento!"; echo ""
  else
    echo -ne "\033[01;33m"; cat $DOMAINS | sort; echo ""
  fi
  echo -e "\033[01;32m Domínio removido com sucesso!"
  echo -e "\033[01;32m Domínio: $DOMAIN"
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAPERTE A TECLA ENTER..."
read ENTER
domainsmanager-remove
exit