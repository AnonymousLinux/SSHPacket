#!/bin/bash

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
if [ -f "/etc/squid/squid.conf" ]; then
  NUMBER=$(grep -c "ATIVO" /etc/squid/squid.conf)
  if [ $NUMBER = "1" ]; then
    echo -e "\033[01;37m  Estado:\033[01;32m ATIVO :)"
  else
    echo -e "\033[01;37m  Estado:\033[01;31m DESATIVADO :("
  fi
fi
echo ""
echo -e "\033[01;36m  [\033[01;37m1\033[01;36m]\033[01;36m Adicionar um domínio a lista de domínios permitidos."
echo -e "\033[01;36m  [\033[01;37m2\033[01;36m]\033[01;36m Ativar Proxy Squid."
echo -e "\033[01;36m  [\033[01;37m3\033[01;36m]\033[01;36m Desativar Proxy Squid."
echo -e "\033[01;36m  [\033[01;37m4\033[01;36m]\033[01;36m Remover um domínio a lista de domínios permitidos."
echo -e "\033[01;36m  [\033[01;37m5\033[01;36m]\033[01;36m Voltar."
echo ""
echo -ne "\033[01;36m  [\033[01;37m1-5\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  1) domainsmanager-add;;
  2) if [ -f "/etc/squid/squid.conf" ]; then
        NUMBER=$(grep -c "ATIVO" /etc/squid/squid.conf)
        if [ $NUMBER = "1" ]; then
          echo ""
          echo -e "\033[01;37;44mProxy Squid já está ATIVO!\033[0m"
          sleep 3s
          domainsmanager-menu
          exit
        else
          grep -v "# DESATIVADO" /etc/squid/squid.conf > squid.txt
          mv squid.txt /etc/squid/squid.conf
          echo "# ATIVO" >> /etc/squid/squid.conf
          if [ ! -f "/etc/init.d/squid" ]; then
            service squid start 1> /dev/null 2> /dev/null
          else
            /etc/init.d/squid start 1> /dev/null 2> /dev/null
          fi
          clear
          domainsmanager-menu
          exit
        fi
      fi;;
  3) if [ -f "/etc/squid/squid.conf" ]; then
        NUMBER=$(grep -c "ATIVO" /etc/squid/squid.conf)
        if [ $NUMBER = "1" ]; then
          grep -v "# ATIVO" /etc/squid/squid.conf > squid.txt
          mv squid.txt /etc/squid/squid.conf
          echo "# DESATIVADO" >> /etc/squid/squid.conf
          if [ ! -f "/etc/init.d/squid" ]; then
            service squid stop 1> /dev/null 2> /dev/null
          else
            /etc/init.d/squid stop 1> /dev/null 2> /dev/null
          fi
          clear
          domainsmanager-menu
          exit
        else
          echo ""
          echo -e "\033[01;37;44mProxy Squid não está ATIVO!\033[0m"
          sleep 3s
          domainsmanager-menu
          exit
        fi
      fi;;
  4) domainsmanager-remove;;
  5) sshpacket;;
  *) domainsmanager-menu;:
esac