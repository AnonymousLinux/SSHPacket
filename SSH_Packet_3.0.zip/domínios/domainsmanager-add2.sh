#!/bin/bash

DOMAINS="/etc/squid3/domains.txt"

if [ ! -f "$DOMAINS" ]; then
  touch $DOMAINS
  domainsmanager-add
  exit
else
  clear
  echo -e "\033[01;36mLista de domínios atuais:\033[01;32m 0: Retornar ao menu."
  echo ""
  NUMBER=$(awk 'END{print NR}' $DOMAINS)
  if [ $NUMBER = "0" ]; then
    echo -e "\033[01;33mVocê não possui nenhum domínio adicionando no momento!"; echo ""
  else
    echo -ne "\033[01;37m"; cat $DOMAINS | sort; echo ""
  fi
  echo -ne "\033[01;36mDigite um domínio para adicionar a lista:\033[01;37m "; read DOMAIN
if [ -z $DOMAIN ]; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um domínio vazio. Tente novamente!\033[0m"
  sleep 3s
  domainsmanager-add
  exit
else
if [ "$DOMAIN" = "0" ]; then
  domainsmanager-menu
  exit
else
if [[ $DOMAIN != \.* ]]; then
  echo ""
  echo -e "\033[01;37;41mVocê deve adicionar um domínio iniciando-o com um ponto (.). P\033[0m"; echo -e "\033[01;37;41mor exemplo: .anonymouslinux.com. Tente novamente!             \033[0m"
  sleep 7s
  domainsmanager-add
  exit
else
if grep -xq "$DOMAIN" $DOMAINS; then
  echo ""
  echo -e "\033[01;37;41mVocê digitou um domínio já existente. Digite um domínio que nã\033[0m"; echo -e "\033[01;37;41mo seja existente na lista acima. Tente novamente!             \033[0m"
  sleep 7s
  domainsmanager-add
  exit
else
  echo "$DOMAIN" >> $DOMAINS
  if [ ! -f "/etc/init.d/squid3" ]; then
    service squid3 reload 1> /dev/null 2> /dev/null
  else
    /etc/init.d/squid3 reload 1> /dev/null 2> /dev/null
  fi
  clear
  echo -e "\033[01;36mLista de domínios atuais:"; echo ""
  echo -ne "\033[01;33m"; cat $DOMAINS | sort; echo ""
  echo -e "\033[01;32m Domínio adicionado com sucesso!"
  echo -e "\033[01;32m Domínio: $DOMAIN"
fi
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAPERTE A TECLA ENTER..."
read ENTER
domainsmanager-add
exit