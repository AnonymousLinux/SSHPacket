#!/bin/bash

checkdatabase

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;36m  [\033[01;37m1\033[01;36m]\033[01;36m Desinstalar gerenciador SSH Packet."
echo -e "\033[01;36m  [\033[01;37m2\033[01;36m]\033[01;36m Funções extras."
echo -e "\033[01;36m  [\033[01;37m3\033[01;36m]\033[01;36m Gerenciamento de usuários SSH."
echo -e "\033[01;36m  [\033[01;37m4\033[01;36m]\033[01;36m Gerenciamento do Proxy Squid."
echo -e "\033[01;36m  [\033[01;37m5\033[01;36m]\033[01;36m Sobre."
echo -e "\033[01;36m  [\033[01;37m6\033[01;36m]\033[01;36m Sair."
echo ""
echo -ne "\033[01;36m  [\033[01;37m1-6\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  1) uninstall;;
  2) extra-menu;;
  3) usersmanager-menu;;
  4) domainsmanager-menu;;
  5) about;;
  6) echo ""
      exit;;
  *) sshpacket;;
esac




