#!/bin/bash

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -ne "\033[01;36m Deseja realmente desinstalar o gerenciador SSH Packet? [N/Y]:\033[01;37m "; read OPTIONS
if [ -z $OPTIONS ]; then
  uninstall
  exit
else
if echo $OPTIONS | grep -q '[^N,Y]'; then
  uninstall
  exit
else
if [ "$OPTIONS" = "N" ]; then
  sshpacket
  exit
else
if [ "$OPTIONS" = "Y" ]; then
  cd /bin
  rm -rf about 1> /dev/null 2> /dev/null
  rm -rf backupsmanager-export 1> /dev/null 2 > /dev/null
  rm -rf backupsmanager-import 1> /dev/null 2 > /dev/null
  rm -rf backupsmanager-menu 1> /dev/null 2 > /dev/null
  rm -rf backupsmanager-remove 1> /dev/null 2 > /dev/null
  rm -rf badvpn-menu 1> /dev/null 2 > /dev/null
  rm -rf badvpn-setup 1> /dev/null 2 > /dev/null
  rm -rf badvpn-uninstall 1> /dev/null 2 > /dev/null
  rm -rf bannerssh 1> /dev/null 2 > /dev/null
  rm -rf changedate 1> /dev/null 2 > /dev/null
  rm -rf changehostname 1> /dev/null 2> /dev/null
  rm -rf changelimit 1> /dev/null 2 > /dev/null
  rm -rf changepassword 1> /dev/null 2 > /dev/null
  rm -rf changerootpassword 1> /dev/null 2 > /dev/null
  rm -rf checkdatabase 1> /dev/null 2 > /dev/null
  rm -rf checkusers 1> /dev/null 2 > /dev/null
  rm -rf connectiontest 1> /dev/null 2 > /dev/null
  rm -rf createuser 1> /dev/null 2 > /dev/null
  rm -rf domainsmanager-add 1> /dev/null 2 > /dev/null
  rm -rf domainsmanager-menu 1> /dev/null 2 > /dev/null
  rm -rf domainsmanager-remove 1> /dev/null 2 > /dev/null
  rm -rf extra-menu 1> /dev/null 2 > /dev/null
  rm -rf limiter-menu 1> /dev/null 2 > /dev/null
  rm -rf limiter-messages 1> /dev/null 2> /dev/null
  rm -rf limiter-start 1> /dev/null 2 > /dev/null
  rm -rf monitoring 1> /dev/null 2 > /dev/null
  rm -rf removeexpired 1> /dev/null 2 > /dev/null
  rm -rf removeuser 1> /dev/null 2 > /dev/null
  rm -rf speedtest 1> /dev/null 2 > /dev/null
  rm -rf sshpacket 1> /dev/null 2 > /dev/null
  rm -rf uninstall 1> /dev/null 2 > /dev/null
  rm -rf userdisconnect 1> /dev/null 2> /dev/null
  rm -rf usersmanager-menu 1> /dev/null 2 > /dev/null
  cd /home
  rm -rf DATABASE 1> /dev/null 2> /dev/null
  if [ -d "/etc/squid" ]; then
    cd /etc/squid
    rm domains.txt 1> /dev/null 2> /dev/null
    echo " " > squid.conf
    if [ -f "/etc/init.d/squid" ]; then
      /etc/init.d/squid restart 1> /dev/null 2> /dev/null
    else
      service squid restart 1> /dev/null 2> /dev/null
    fi
  fi
  if [ -d "/etc/squid3" ]; then
    cd /etc/squid3
    rm domains.txt 1> /dev/null 2> /dev/null
    echo " " > squid.conf
    if [ -f "/etc/init.d/squid3" ]; then
      /etc/init.d/squid3 restart 1> /dev/null 2> /dev/null
    else
      service squid3 restart 1> /dev/null 2> /dev/null
    fi
  fi
  cat /etc/ssh/sshd_config | grep -v "Banner /home/DATABASE/bannerssh.txt" > ssh.txt
  mv ssh.txt /etc/ssh/sshd_config 
  cat /etc/ssh/sshd_config | grep -v "PasswordAuthentication yes" > ssh.txt
  mv ssh.txt /etc/ssh/sshd_config 
  cat /etc/ssh/sshd_config | grep -v "PermitEmptyPasswords yes" > ssh.txt
  mv ssh.txt /etc/ssh/sshd_config 
  cat /etc/ssh/sshd_config | grep -v "Port 443" > ssh.txt
  mv ssh.txt /etc/ssh/sshd_config
  if [ -f "/etc/init.d/ssh" ]; then
    /etc/init.d/ssh restart 1> /dev/null 2> /dev/null
  else
    service ssh restart 1> /dev/null 2> /dev/null
  fi
  clear
  echo ""
  echo -e "\033[01;37m ------------------------------------------------------------------"
  echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
  echo -e "\033[01;37m ------------------------------------------------------------------"
  echo ""
  echo -e "\033[01;36m SSH Packet desinstalado com sucesso!\033[01;37m"
  echo ""
fi
fi
fi
fi
exit
  
  
  