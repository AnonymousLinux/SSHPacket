#!/bin/bash

function about1 () {
clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;36m Desenvolvedor:\033[01;37m Carlos"
echo -e "\033[01;36m Github:\033[01;37m https://github.com/AnonymousLinux"
echo -e "\033[01;36m Email:\033[01;37m anonymouslinuxoficial@gmail.com"
echo -e "\033[01;36m Telegram (Chat):\033[01;37m @Oloco2"
echo -e "\033[01;36m Telegram (Channel):\033[01;37m @AnonymousLinux"
echo -e "\033[01;36m Telegram (Group):\033[01;37m https://t.me/joinchat/D1XtDUSC9HnmICbzQk6_GQ"
echo ""
echo -e "\033[01;37mAperte a tecla ENTER para voltar ao menu..."
read ENTER
about
exit
}

function about2 () {
clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;36m Nome:\033[01;37m SSH Packet"
echo -e "\033[01;36m Versão:\033[01;37m 3.0"
echo -e "\033[01;36m Desenvolvedor:\033[01;37m Carlos"
echo -e "\033[01;36m Github:\033[01;37m https://github.com/AnonymousLinux/SSHPacket"
echo -e "\033[01;36m Linguagem:\033[01;37m Shell Script"
echo -e "\033[01;36m Criado em:\033[01;37m 11/06/2017"
echo -e "\033[01;36m Última atualização:\033[01;37m 26/08/2017"
echo ""
echo -e "\033[01;37mAperte a tecla ENTER para voltar ao menu..."
read ENTER
about
exit
}

function about3 () {
clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;37m TERMOS DE USO (!):"
echo ""
echo -e "\033[01;37m Você concorda que:"
echo -e "\033[01;36m ● O utilizador deste conjunto de scripts é o único responsável por"
echo -e "\033[01;36m executar as funções do mesmo."
echo ""
echo -ne "\033[01;37m Aperte a tecla ENTER para prosseguir..."; read ENTER
echo ""
echo -e "\033[01;37m Você não pode:"
echo -e "\033[01;36m ● Editar ou modificar o conjunto de scripts para fins lucrativos."
echo -e "\033[01;36m ● Vender ou alugar o conjunto de scripts."
echo ""
echo -ne "\033[01;37m Aperte a tecla ENTER para prosseguir..."; read ENTER
echo ""
echo -e "\033[01;37m Você pode:"
echo -e "\033[01;36m ● Editar ou modificar o conjunto de scripts ao seu gosto e prazer,"
echo -e "\033[01;36m mas nunca vender ou alugar o mesmo! Tenha bom senso de sempre deixa"
echo -e "\033[01;36m r o nome do criador como referência."
echo ""
echo -ne "\033[01;37m Aperte a tecla ENTER para prosseguir..."; read ENTER
echo ""
echo -e "\033[01;37m Você concorda que o desenvolvedor não se responsabilizará pelos:"
echo -e "\033[01;36m ● Problemas causados por conflitos entre este conjunto de scripts e"
echo -e "\033[01;36m de outros desenvolvedores."
echo -e "\033[01;36m ● Problemas causados por edições ou modificações do código deste co"
echo -e "\033[01;36m njunto de scripts."
echo -e "\033[01;36m ● Problemas causados por modificações no sistema do servidor."
echo -e "\033[01;36m ● Problemas que possam ocorrer ao usar este conjunto de scripts em"
echo -e "\033[01;36m sistemas que não estão na lista de sistemas testados."
echo ""
echo -ne "\033[01;37mAperte a tecla ENTER para voltar ao menu..."; read ENTER
about
exit
}

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;36m  [\033[01;37m1\033[01;36m]\033[01;36m Desenvolvedor."
echo -e "\033[01;36m  [\033[01;37m2\033[01;36m]\033[01;36m Sobre o projeto SSH Packet."
echo -e "\033[01;36m  [\033[01;37m3\033[01;36m]\033[01;36m Termos de uso."
echo -e "\033[01;36m  [\033[01;37m4\033[01;36m]\033[01;36m Voltar."
echo ""
echo -ne "\033[01;36m  [\033[01;37m1-4\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  1) about1;;
  2) about2;;
  3) about3;;
  4) sshpacket;;
  *) about;;
esac











