#!/bin/bash

DATABASE="/home/DATABASE"
BACKUPS="/home/DATABASE/Backups"
BANNERSSH="/home/DATABASE/bannerssh.txt"
MESSAGES="/home/DATABASE/messages.txt"
USERS="/home/DATABASE/users.db"

if [ ! -d "$DATABASE" ]; then
  mkdir $DATABASE
fi
if [ ! -d "$BACKUPS" ]; then
  mkdir $BACKUPS
fi
if [ ! -f "$BANNERSSH" ]; then
  touch $BANNERSSH
fi
if [ ! -f "$MESSAGES" ]; then
  touch $MESSAGES
fi
if [ ! -f "$USERS" ]; then
  touch $USERS
  awk -F : '$3 >= 500 { print $1 " 1" }' /etc/passwd | grep -v "nobody" | sort > $USERS
fi