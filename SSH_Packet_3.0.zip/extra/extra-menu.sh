#!/bin/bash

checkdatabase

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;36m  [\033[01;37m1\033[01;36m]\033[01;36m Alterar a senha de usuário ROOT."
echo -e "\033[01;36m  [\033[01;37m2\033[01;36m]\033[01;36m Alterar hostname do servidor."
echo -e "\033[01;36m  [\033[01;37m3\033[01;36m]\033[01;36m Gerenciamento do programa BadVPN."
echo -e "\033[01;36m  [\033[01;37m4\033[01;36m]\033[01;36m Teste de velocidade (CONEXÃO) do servidor."
echo -e "\033[01;36m  [\033[01;37m5\033[01;36m]\033[01;36m Voltar."
echo ""
echo -ne "\033[01;36m  [\033[01;37m1-5\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  1) changerootpassword;;
  2) changehostname;;
  3) badvpn-menu;;
  4) connectiontest;;
  5) sshpacket;;
  *) extra-menu;;
esac





