#!/bin/bash

clear
echo -e "\033[01;36mSenha de usuário ROOT atual: \033[01;37m0: Retornar ao menu."
echo ""
echo -e "\033[01;32m********"
echo ""
echo -ne "\033[01;36mNova senha de usuário ROOT:\033[01;37m "; read PASSWORD
if [ -z $PASSWORD ] ; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou uma senha vazia. Tente novamente!\033[0m"
  sleep 3s
  changerootpassword
  exit
else
if [ "$PASSWORD" = "0" ]; then
  extra-menu
  exit
else
  CHARACTERS=$(echo $PASSWORD | wc -c)
if [ $CHARACTERS -lt 9 ]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou uma senha de usuário ROOT muito curta. Use no míni\033[0m"; echo -e "\033[01;37;44mmo 8 caracteres para a senha de usuário ROOT. Tente novamente! \033[0m"
  sleep 7s
  changerootpassword
  exit
else
  (echo $PASSWORD; echo $PASSWORD) | passwd root 1> /dev/null 2> /dev/null
  clear
  echo -e "\033[01;36mSenha de usuário ROOT atual:"
  echo ""
  echo -e "\033[01;32m********"
  echo ""
  echo -e "\033[01;37mSenha de usuário ROOT alterada com sucesso!"
  echo -e "\033[01;37mSenha de usuário ROOT alterada para: $PASSWORD"
fi
fi
fi
echo ""
echo -ne "\033[01;36mAperte a tecla ENTER..."
read ENTER
changerootpassword
exit