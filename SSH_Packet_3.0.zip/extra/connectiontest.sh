#!/bin/bash

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""
echo -e "\033[01;36mAguarde..."
echo ""
speedtest > /tmp/connectiontest
IP=$(cat /tmp/connectiontest | grep -E "Testing from" | cut -d "(" -f2 | cut -d ")" -f1)
PING=$(cat /tmp/connectiontest  | grep -E "Hosted" | cut -d " " -f7,8 | sed 's/km]: //g')
DOWNLOAD=$(cat /tmp/connectiontest  | grep -E "Download" | cut -d " " -f2,3)
UPLOAD=$(cat /tmp/connectiontest  | grep -E "Upload" | cut -d " " -f2,3)
echo -e "\033[01;36mIP:\033[01;37m $IP"
echo -e "\033[01;36mPing:\033[01;37m $PING"
echo -e "\033[01;36mVelocidade de Download:\033[01;37m $DOWNLOAD"
echo -e "\033[01;36mVelocidade de Upload:\033[01;37m $UPLOAD"
echo ""
while true; do
  echo -ne "\033[01;36mDeseja refazer o teste? [N/Y]:\033[01;37m "; read NY
  if [ "$NY" = "N" ]; then
    extra-menu
    exit
  else
  if [ "$NY" = "Y" ]; then
    connectiontest
    exit
  fi
  fi
done