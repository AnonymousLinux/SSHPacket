#!/bin/bash

BADVPN="/home/DATABASE/BadVPN"
UDP="/bin/udp"

if [ ! -f "$UDP" ]; then
  echo ""
  echo -e "\033[01;37;44mVocê não possui o BadVPN instalado!\033[0m"
  sleep 3s
  badvpn-menu
  exit 
else
  clear
  echo -e "\033[01;37m ------------------------------------------------------------------"
  echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
  echo -e "\033[01;37m ------------------------------------------------------------------"
  echo ""
  echo -e "\033[01;36m ● Desinstalando BadVPN.."
  rm -rf $BADVPN
  rm -rf $UDP
  sleep 3s
  clear
  echo -e "\033[01;37m ------------------------------------------------------------------"
  echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
  echo -e "\033[01;37m ------------------------------------------------------------------"
  echo ""
  echo -e "\033[01;36m BadVPN desinstalado com sucesso!"
fi
echo ""
echo -e "\033[01;37mAperte a tecla ENTER para voltar ao menu..."
read ENTER
badvpn-menu
exit