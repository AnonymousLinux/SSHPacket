#!/bin/bash

checkdatabase

UDP="/bin/udp"

clear
echo -e "\033[01;37m ------------------------------------------------------------------"
echo -e "\033[01;37m|                            \033[01;36mSSH Packet\033[01;37m                            |"
echo -e "\033[01;37m ------------------------------------------------------------------"
echo ""

if [ -f "$UDP" ]; then
  echo -e "\033[01;36m Instalação:\033[01;37m Instalado"
else
  echo -e "\033[01;36m Instalação:\033[01;37m Desinstalado"
fi

NUMBER=$(ps -x | grep -c "badvpn-udpgw")
if [ $NUMBER = "2" ]; then
  echo -e "\033[01;36m Estado:\033[01;32m ATIVO"
else
  echo -e "\033[01;36m Estado:\033[01;31m DESATIVADO"
fi

echo ""
echo -e "\033[01;36m  [\033[01;37m1\033[01;36m]\033[01;36m Ativar serviço BadVPN."
echo -e "\033[01;36m  [\033[01;37m2\033[01;36m]\033[01;36m Desativar serviço BadVPN."
echo -e "\033[01;36m  [\033[01;37m3\033[01;36m]\033[01;36m Desinstalar o programa BadVPN."
echo -e "\033[01;36m  [\033[01;37m4\033[01;36m]\033[01;36m Instalar o programa BadVPN."
echo -e "\033[01;36m  [\033[01;37m5\033[01;36m]\033[01;36m Voltar."
echo ""
echo -ne "\033[01;36m  [\033[01;37m1-5\033[01;36m]:\033[01;37m "; read NUMBERS
case $NUMBERS in
  1) if [ ! -f "$UDP" ]; then
        echo ""
        echo -e "\033[01;37;41mVocê não possui o BadVPN instalado!\033[0m"
        sleep 3s
        badvpn-menu
        exit
      fi
      NUMBER=$(ps -x | grep -c "badvpn-udpgw")
      if [ $NUMBER = "2" ]; then
        echo ""
        echo -e "\033[01;37;41mServiço BadVPN já está ATIVO!\033[0m"
        sleep 3s
        badvpn-menu
        exit
      else
        echo ""
        echo -e "\033[01;37mAguarde..."
        udp&> /dev/null & 
        sleep 3s
        clear
        badvpn-menu
        exit
      fi;;
  2) if [ ! -f "$UDP" ]; then
        echo ""
        echo -e "\033[01;37;41mVocê não possui o BadVPN instalado!\033[0m"
        sleep 3s
        badvpn-menu
        exit
      fi
      NUMBER=$(ps -x | grep -c "badvpn-udpgw")
      if [ $NUMBER = "2" ]; then
        echo ""
        echo -e "\033[01;37mAguarde..."
        pkill -f udp
        sleep 3s
        clear
        badvpn-menu
        exit
      else
        echo ""
        echo -e "\033[01;37;41mServiço BadVPN não está ATIVO!\033[0m"
        sleep 3s
        badvpn-menu
        exit
      fi;;
  3) badvpn-uninstall;;
  4) badvpn-setup;;
  5) extra-menu;;
  *) badvpn-menu;;
esac