#!/bin/bash

clear
echo -e "\033[01;36mHostname atual: \033[01;37m0: Retornar ao menu."; echo ""
echo -ne "\033[01;32m"; hostname; echo ""
echo -ne "\033[01;36mNome para alterar o hostname:\033[01;37m "; read NAME
if [ -z $NAME ]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome para alterar o hostname inválido. Tente novamente!\033[0m"
  sleep 3s
  changehostname
  exit
else
if [ "$NAME" = "0" ]; then
  extra-menu
  exit
else
  HOSTNAME=$(hostname)
if [ "$NAME" = $HOSTNAME ]; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome para alterar o hostname inválido. Tente novamente!\033[0m"
  sleep 3s
  changehostname
  exit
else
if echo $NAME | grep -q '[^a-zA-Z0-9-]'; then
  echo ""
  echo -e "\033[01;37;44mVocê digitou um nome de hostname inválido. Use apenas letras\033[0m"; echo -e "\033[01;37;44mnúmeros e traços. Não use espaços, acentos, pontos ou caract\033[0m"; echo -e "\033[01;37;44mers especiais. Tente novamente!                             \033[0m"
  sleep 8s
  changehostname
  exit
else
  hostname $NAME
  clear
  echo -e "\033[01;36mHostname atual:"; echo ""
  echo -ne "\033[01;32m"; hostname; echo ""
  echo -e "\033[01;37mHostname alterado com sucesso!"
  echo -e "\033[01;37mHostname alterado para: $NAME"
fi
fi
fi
fi
echo ""
echo -ne "\033[01;36mAperte a tecla ENTER..."
read ENTER
changehostname
exit

  
  

